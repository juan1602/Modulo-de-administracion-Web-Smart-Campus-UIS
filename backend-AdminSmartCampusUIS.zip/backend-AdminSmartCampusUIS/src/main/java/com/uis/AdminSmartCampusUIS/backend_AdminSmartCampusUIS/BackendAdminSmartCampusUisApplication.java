package com.uis.AdminSmartCampusUIS.backend_AdminSmartCampusUIS;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackendAdminSmartCampusUisApplication {

	public static void main(String[] args) {
		SpringApplication.run(BackendAdminSmartCampusUisApplication.class, args);
	}

}
