package com.uis.AdminSmartCampusUIS.backend_AdminSmartCampusUIS;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackendAdminSmartCampusUisApplicationTests {

	@Test
	void contextLoads() {
	}

}
